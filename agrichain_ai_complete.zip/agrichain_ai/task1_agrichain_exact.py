"""
AgriChain AI - Task 1
Data Preparation and Exploration

Expected input files:
    complaints_train.csv
    complaints_test.csv

The script:
1. Loads the supplied train/test datasets
2. Validates the exact schema
3. Normalizes complaint text
4. Removes stopwords
5. Encodes the 8 complaint categories
6. Creates EDA summaries
7. Visualizes category, region, channel and time trends
8. Detects class imbalance
9. Creates a balanced TRAINING dataset only
10. Preserves the original TEST dataset for unbiased evaluation
"""

from pathlib import Path
import json
import re

import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder
from sklearn.utils import resample
import joblib


# ---------------------------------------------------------------------
# CONFIGURATION
# ---------------------------------------------------------------------

RANDOM_STATE = 42

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
RAW_DIR = DATA_DIR / "raw"
PROCESSED_DIR = DATA_DIR / "processed"
MODEL_DIR = BASE_DIR / "models"
EDA_DIR = BASE_DIR / "artifacts" / "eda"

TRAIN_FILE = RAW_DIR / "complaints_train.csv"
TEST_FILE = RAW_DIR / "complaints_test.csv"

EXPECTED_COLUMNS = [
    "complaint_id",
    "timestamp",
    "customer_id",
    "channel",
    "complaint_text",
    "category",
    "priority",
    "supplier_id",
    "product_category",
    "region",
    "order_id",
]

EXPECTED_CATEGORIES = [
    "Damaged Goods",
    "Delivery Delay",
    "Documentation Error",
    "Missing Items",
    "Poor Communication",
    "Pricing Error",
    "Quality Issues",
    "Service Complaint",
]


# ---------------------------------------------------------------------
# BASIC STOPWORDS
# ---------------------------------------------------------------------

STOPWORDS = {
    "a", "an", "the", "and", "or", "but", "if", "while", "of", "at", "by",
    "for", "with", "about", "against", "between", "into", "through", "during",
    "before", "after", "above", "below", "to", "from", "up", "down", "in",
    "out", "on", "off", "over", "under", "again", "further", "then", "once",
    "here", "there", "when", "where", "why", "how", "all", "any", "both",
    "each", "few", "more", "most", "other", "some", "such", "no", "nor",
    "not", "only", "own", "same", "so", "than", "too", "very", "can", "will",
    "just", "is", "are", "was", "were", "be", "been", "being", "have", "has",
    "had", "do", "does", "did", "this", "that", "these", "those", "i", "you",
    "he", "she", "it", "we", "they", "my", "your", "our", "their"
}


# ---------------------------------------------------------------------
# DATA LOADING AND VALIDATION
# ---------------------------------------------------------------------

def load_data():
    train = pd.read_csv(TRAIN_FILE)
    test = pd.read_csv(TEST_FILE)

    validate_schema(train, "training")
    validate_schema(test, "test")

    return train, test


def validate_schema(df, dataset_name):
    missing = [c for c in EXPECTED_COLUMNS if c not in df.columns]

    if missing:
        raise ValueError(
            f"{dataset_name.title()} dataset is missing columns: {missing}"
        )

    categories = sorted(df["category"].dropna().unique().tolist())

    if sorted(EXPECTED_CATEGORIES) != categories:
        raise ValueError(
            f"{dataset_name.title()} categories differ from the expected 8.\n"
            f"Found: {categories}"
        )


# ---------------------------------------------------------------------
# TEXT PREPROCESSING
# ---------------------------------------------------------------------

def normalize_text(text):
    """
    Normalize complaint text while preserving useful business tokens.

    We remove:
    - URLs
    - e-mail addresses
    - punctuation
    - excess whitespace
    - common stopwords

    Order IDs and supplier IDs are intentionally retained as alphanumeric
    tokens because later agent/RAG workflows may use them.
    """
    text = "" if pd.isna(text) else str(text)
    text = text.lower()

    text = re.sub(r"http\S+|www\.\S+", " ", text)
    text = re.sub(r"\S+@\S+", " ", text)

    # Convert ORD-123456 -> ord 123456 rather than deleting the identifier.
    text = re.sub(r"[^a-z0-9\s]", " ", text)

    text = re.sub(r"\s+", " ", text).strip()

    tokens = [
        token for token in text.split()
        if token not in STOPWORDS
    ]

    return " ".join(tokens)


def preprocess(df):
    out = df.copy()

    out["timestamp"] = pd.to_datetime(
        out["timestamp"],
        errors="coerce"
    )

    if out["timestamp"].isna().any():
        raise ValueError("Some timestamps could not be parsed.")

    # Standardize categorical text fields.
    categorical_columns = [
        "channel",
        "category",
        "priority",
        "supplier_id",
        "product_category",
        "region",
    ]

    for col in categorical_columns:
        out[col] = out[col].astype(str).str.strip()

    out["complaint_text"] = (
        out["complaint_text"]
        .astype(str)
        .str.strip()
    )

    out["clean_text"] = (
        out["complaint_text"]
        .apply(normalize_text)
    )

    # Useful temporal features for EDA.
    out["date"] = out["timestamp"].dt.date
    out["month"] = out["timestamp"].dt.to_period("M").astype(str)
    out["day_of_week"] = out["timestamp"].dt.day_name()
    out["hour"] = out["timestamp"].dt.hour

    return out


# ---------------------------------------------------------------------
# CATEGORY ENCODING
# ---------------------------------------------------------------------

def encode_categories(train, test):
    """
    Fit the LabelEncoder ONLY on training labels.
    Apply the same encoder to the held-out test set.
    """
    encoder = LabelEncoder()

    train = train.copy()
    test = test.copy()

    train["category_encoded"] = encoder.fit_transform(
        train["category"]
    )

    test["category_encoded"] = encoder.transform(
        test["category"]
    )

    MODEL_DIR.mkdir(parents=True, exist_ok=True)

    joblib.dump(
        encoder,
        MODEL_DIR / "label_encoder.joblib"
    )

    mapping = {
        category: int(index)
        for index, category in enumerate(encoder.classes_)
    }

    with open(
        MODEL_DIR / "category_mapping.json",
        "w",
        encoding="utf-8"
    ) as f:
        json.dump(mapping, f, indent=2)

    return train, test, encoder


# ---------------------------------------------------------------------
# CLASS BALANCING
# ---------------------------------------------------------------------

def balance_training_set(train):
    """
    Randomly oversample minority classes to the size of the largest class.

    IMPORTANT:
    Only the training data is balanced.
    The test distribution remains untouched for honest evaluation.
    """
    max_count = train["category"].value_counts().max()

    groups = []

    for category, group in train.groupby("category"):
        if len(group) < max_count:
            sampled = resample(
                group,
                replace=True,
                n_samples=max_count,
                random_state=RANDOM_STATE,
            )
        else:
            sampled = group.copy()

        groups.append(sampled)

    balanced = pd.concat(
        groups,
        ignore_index=True
    )

    balanced = balanced.sample(
        frac=1,
        random_state=RANDOM_STATE
    ).reset_index(drop=True)

    return balanced


# ---------------------------------------------------------------------
# EDA
# ---------------------------------------------------------------------

def save_bar_plot(series, title, xlabel, filename):
    ax = series.plot(
        kind="bar",
        figsize=(10, 6)
    )

    ax.set_title(title)
    ax.set_xlabel(xlabel)
    ax.set_ylabel("Number of complaints")

    plt.xticks(rotation=45, ha="right")
    plt.tight_layout()
    plt.savefig(
        EDA_DIR / filename,
        dpi=160
    )
    plt.close()


def create_eda(train, test):
    EDA_DIR.mkdir(parents=True, exist_ok=True)

    combined = pd.concat(
        [
            train.assign(dataset="train"),
            test.assign(dataset="test")
        ],
        ignore_index=True
    )

    # ----------------------------
    # Complaint category frequency
    # ----------------------------
    save_bar_plot(
        train["category"].value_counts(),
        "Training Complaints by Category",
        "Complaint category",
        "01_category_distribution.png",
    )

    # ----------------------------
    # Region
    # ----------------------------
    save_bar_plot(
        combined["region"].value_counts(),
        "Complaints by Region",
        "Region",
        "02_region_distribution.png",
    )

    # ----------------------------
    # Channel
    # ----------------------------
    save_bar_plot(
        combined["channel"].value_counts(),
        "Complaints by Channel",
        "Channel",
        "03_channel_distribution.png",
    )

    # ----------------------------
    # Priority
    # ----------------------------
    priority_order = [
        "low",
        "medium",
        "high",
        "critical"
    ]

    priority_counts = (
        combined["priority"]
        .value_counts()
        .reindex(priority_order)
        .fillna(0)
    )

    save_bar_plot(
        priority_counts,
        "Complaints by Priority",
        "Priority",
        "04_priority_distribution.png",
    )

    # ----------------------------
    # Monthly trend
    # ----------------------------
    monthly = (
        combined
        .set_index("timestamp")
        .resample("ME")
        .size()
    )

    ax = monthly.plot(
        kind="line",
        marker="o",
        figsize=(11, 6)
    )

    ax.set_title("Complaint Volume Over Time")
    ax.set_xlabel("Month")
    ax.set_ylabel("Number of complaints")

    plt.tight_layout()

    plt.savefig(
        EDA_DIR / "05_monthly_trend.png",
        dpi=160
    )

    plt.close()

    # ----------------------------
    # Category x region
    # ----------------------------
    category_region = pd.crosstab(
        combined["category"],
        combined["region"]
    )

    category_region.plot(
        kind="bar",
        figsize=(12, 7)
    )

    plt.title("Complaint Categories by Region")
    plt.xlabel("Complaint category")
    plt.ylabel("Number of complaints")
    plt.xticks(rotation=45, ha="right")
    plt.tight_layout()

    plt.savefig(
        EDA_DIR / "06_category_by_region.png",
        dpi=160
    )

    plt.close()

    # ----------------------------
    # Category x channel
    # ----------------------------
    category_channel = pd.crosstab(
        combined["category"],
        combined["channel"]
    )

    category_channel.plot(
        kind="bar",
        figsize=(12, 7)
    )

    plt.title("Complaint Categories by Channel")
    plt.xlabel("Complaint category")
    plt.ylabel("Number of complaints")
    plt.xticks(rotation=45, ha="right")
    plt.tight_layout()

    plt.savefig(
        EDA_DIR / "07_category_by_channel.png",
        dpi=160
    )

    plt.close()


# ---------------------------------------------------------------------
# SUMMARY REPORT
# ---------------------------------------------------------------------

def build_summary(train, test, balanced):
    train_counts = train["category"].value_counts()
    test_counts = test["category"].value_counts()
    balanced_counts = balanced["category"].value_counts()

    summary = {
        "training_rows": int(len(train)),
        "test_rows": int(len(test)),
        "total_rows": int(len(train) + len(test)),
        "number_of_categories": int(train["category"].nunique()),

        "training_date_range": {
            "start": str(train["timestamp"].min()),
            "end": str(train["timestamp"].max()),
        },

        "test_date_range": {
            "start": str(test["timestamp"].min()),
            "end": str(test["timestamp"].max()),
        },

        "missing_values_training": (
            train[EXPECTED_COLUMNS]
            .isna()
            .sum()
            .to_dict()
        ),

        "missing_values_test": (
            test[EXPECTED_COLUMNS]
            .isna()
            .sum()
            .to_dict()
        ),

        "training_category_counts": (
            train_counts.to_dict()
        ),

        "test_category_counts": (
            test_counts.to_dict()
        ),

        "balanced_training_category_counts": (
            balanced_counts.to_dict()
        ),

        "largest_training_class": str(
            train_counts.idxmax()
        ),

        "largest_training_class_count": int(
            train_counts.max()
        ),

        "smallest_training_class": str(
            train_counts.idxmin()
        ),

        "smallest_training_class_count": int(
            train_counts.min()
        ),

        "imbalance_ratio": float(
            train_counts.max() / train_counts.min()
        ),

        "training_channels": (
            train["channel"].value_counts().to_dict()
        ),

        "training_regions": (
            train["region"].value_counts().to_dict()
        ),

        "training_priorities": (
            train["priority"].value_counts().to_dict()
        ),

        "duplicate_training_complaints": int(
            train["complaint_text"].duplicated().sum()
        ),

        "duplicate_test_complaints": int(
            test["complaint_text"].duplicated().sum()
        ),
    }

    return summary


# ---------------------------------------------------------------------
# MAIN PIPELINE
# ---------------------------------------------------------------------

def main():
    PROCESSED_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    print("=" * 70)
    print("AGRiCHAIN AI - TASK 1: DATA PREPARATION AND EXPLORATION")
    print("=" * 70)

    # 1. Load
    train_raw, test_raw = load_data()

    print(f"\nTraining rows: {len(train_raw)}")
    print(f"Test rows:     {len(test_raw)}")

    # 2. Preprocess
    train = preprocess(train_raw)
    test = preprocess(test_raw)

    # 3. Encode labels
    train, test, encoder = encode_categories(
        train,
        test
    )

    # 4. Balance training data
    balanced = balance_training_set(train)

    # 5. EDA
    create_eda(train, test)

    # 6. Save datasets
    train.to_csv(
        PROCESSED_DIR / "complaints_train_processed.csv",
        index=False
    )

    test.to_csv(
        PROCESSED_DIR / "complaints_test_processed.csv",
        index=False
    )

    balanced.to_csv(
        PROCESSED_DIR / "complaints_train_balanced.csv",
        index=False
    )

    # 7. Save summary
    summary = build_summary(
        train,
        test,
        balanced
    )

    with open(
        PROCESSED_DIR / "task1_summary.json",
        "w",
        encoding="utf-8"
    ) as f:
        json.dump(
            summary,
            f,
            indent=2,
            default=str
        )

    print("\nCategory mapping:")
    for category, code in zip(
        encoder.classes_,
        encoder.transform(encoder.classes_)
    ):
        print(f"  {code}: {category}")

    print("\nOriginal training distribution:")
    print(
        train["category"]
        .value_counts()
        .to_string()
    )

    print("\nBalanced training distribution:")
    print(
        balanced["category"]
        .value_counts()
        .to_string()
    )

    print(
        f"\nImbalance ratio: "
        f"{summary['imbalance_ratio']:.2f}:1"
    )

    print("\nTask 1 complete.")
    print(
        f"Processed datasets saved to: "
        f"{PROCESSED_DIR}"
    )

    print(
        f"EDA figures saved to: "
        f"{EDA_DIR}"
    )


if __name__ == "__main__":
    main()
