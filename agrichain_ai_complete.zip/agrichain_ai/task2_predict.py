"""
Load the trained Task 2 ANN and classify new complaints.
"""

from pathlib import Path
import joblib
import numpy as np
import tensorflow as tf
from sentence_transformers import SentenceTransformer

BASE_DIR = Path(__file__).resolve().parent

MODEL_DIR = BASE_DIR / "models"

EMBEDDING_MODEL_NAME = (
    "sentence-transformers/all-MiniLM-L6-v2"
)


def classify_complaint(text):
    encoder = joblib.load(
        MODEL_DIR / "label_encoder.joblib"
    )

    ann = tf.keras.models.load_model(
        MODEL_DIR / "complaint_ann.keras"
    )

    embedding_model = SentenceTransformer(
        EMBEDDING_MODEL_NAME
    )

    embedding = embedding_model.encode(
        [text],
        normalize_embeddings=True,
        convert_to_numpy=True
    ).astype("float32")

    probabilities = ann.predict(
        embedding,
        verbose=0
    )[0]

    indices = np.argsort(
        probabilities
    )[::-1]

    return {
        "predicted_category": str(
            encoder.classes_[indices[0]]
        ),

        "confidence": float(
            probabilities[indices[0]]
        ),

        "top_3": [
            {
                "category": str(
                    encoder.classes_[index]
                ),

                "confidence": float(
                    probabilities[index]
                )
            }

            for index in indices[:3]
        ]
    }


if __name__ == "__main__":
    complaint = (
        "The shipment arrived a week late "
        "and nobody provided an updated ETA."
    )

    print(
        classify_complaint(
            complaint
        )
    )
