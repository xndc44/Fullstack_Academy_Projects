from typing import Any, Dict, List

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from task2_predict import classify_complaint
from task2_rag_retriever import retrieve
from task3_agents import resolve_complaint


app = FastAPI(
    title="AgriChain AI API",
    description=(
        "Backend API for complaint classification, "
        "FAISS retrieval and LangGraph complaint resolution."
    ),
    version="1.0.0"
)


class ComplaintRequest(BaseModel):
    complaint: str = Field(
        min_length=1
    )

    complaint_id: str = ""
    customer_id: str = ""
    supplier_id: str = ""
    order_id: str = ""
    region: str = ""
    channel: str = ""
    provided_priority: str = ""


class SearchRequest(BaseModel):
    query: str = Field(
        min_length=1
    )

    k: int = Field(
        default=5,
        ge=1,
        le=20
    )


@app.get("/")
def root():
    return {
        "service": "AgriChain AI API",
        "status": "running",
        "docs": "/docs"
    }


@app.get("/health")
def health():
    return {
        "status": "ok"
    }


@app.post("/classify")
def classify(
    payload: ComplaintRequest
) -> Dict[str, Any]:
    try:
        return classify_complaint(
            payload.complaint
        )
    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=str(exc)
        )


@app.post("/rag/search")
def rag_search(
    payload: SearchRequest
) -> Dict[str, List[Dict[str, Any]]]:
    try:
        return {
            "results": retrieve(
                payload.query,
                k=payload.k
            )
        }
    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=str(exc)
        )


@app.post("/resolve")
def resolve(
    payload: ComplaintRequest
) -> Dict[str, Any]:
    try:
        return resolve_complaint(
            complaint=payload.complaint,
            complaint_id=payload.complaint_id,
            customer_id=payload.customer_id,
            supplier_id=payload.supplier_id,
            order_id=payload.order_id,
            region=payload.region,
            channel=payload.channel,
            provided_priority=payload.provided_priority
        )
    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=str(exc)
        )
