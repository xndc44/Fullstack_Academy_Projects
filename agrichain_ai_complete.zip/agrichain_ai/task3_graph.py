"""
Print the LangGraph workflow as Mermaid markup.

You can paste the output into Mermaid-compatible Markdown/renderers.
"""

from task3_agents import complaint_graph


def main():
    mermaid = (
        complaint_graph
        .get_graph()
        .draw_mermaid()
    )

    print(
        mermaid
    )


if __name__ == "__main__":
    main()
