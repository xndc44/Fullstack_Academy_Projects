#!/bin/sh
set -eu

echo "Starting FastAPI on http://localhost:8000"
uvicorn api.main:app --host 0.0.0.0 --port 8000 &
API_PID=$!

echo "Starting EDA Dashboard on http://localhost:8501"
streamlit run apps/01_eda_dashboard.py --server.port=8501 &
EDA_PID=$!

echo "Starting Complaint Classifier on http://localhost:8502"
streamlit run apps/02_complaint_classifier.py --server.port=8502 &
CLASSIFIER_PID=$!

echo "Starting RAG Assistant on http://localhost:8503"
streamlit run apps/03_rag_assistant.py --server.port=8503 &
RAG_PID=$!

echo "Starting Multi-Agent System on http://localhost:8504"
streamlit run apps/04_multi_agent_system.py --server.port=8504 &
AGENT_PID=$!

trap 'kill $API_PID $EDA_PID $CLASSIFIER_PID $RAG_PID $AGENT_PID 2>/dev/null || true' INT TERM EXIT

wait
