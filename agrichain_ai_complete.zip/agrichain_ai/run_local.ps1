$ErrorActionPreference = "Stop"

Write-Host "Starting AgriChain services..."

$processes = @()

$processes += Start-Process `
    -FilePath "python" `
    -ArgumentList "-m","uvicorn","api.main:app","--host","0.0.0.0","--port","8000" `
    -PassThru

$processes += Start-Process `
    -FilePath "python" `
    -ArgumentList "-m","streamlit","run","apps/01_eda_dashboard.py","--server.port=8501" `
    -PassThru

$processes += Start-Process `
    -FilePath "python" `
    -ArgumentList "-m","streamlit","run","apps/02_complaint_classifier.py","--server.port=8502" `
    -PassThru

$processes += Start-Process `
    -FilePath "python" `
    -ArgumentList "-m","streamlit","run","apps/03_rag_assistant.py","--server.port=8503" `
    -PassThru

$processes += Start-Process `
    -FilePath "python" `
    -ArgumentList "-m","streamlit","run","apps/04_multi_agent_system.py","--server.port=8504" `
    -PassThru

Write-Host ""
Write-Host "Services:"
Write-Host "  FastAPI:                http://localhost:8000/docs"
Write-Host "  EDA Dashboard:          http://localhost:8501"
Write-Host "  Complaint Classifier:   http://localhost:8502"
Write-Host "  RAG Assistant:          http://localhost:8503"
Write-Host "  Multi-Agent System:     http://localhost:8504"
Write-Host ""
Write-Host "Close the spawned windows/processes when finished."
