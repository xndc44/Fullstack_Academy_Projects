"""
Interactive command-line demonstration of the complete Task 3 workflow.
"""

import json

from task3_agents import resolve_complaint


def main():
    print(
        "\nAgriChain AI Multi-Agent Complaint Resolution\n"
    )

    complaint = input(
        "Enter complaint: "
    ).strip()

    if not complaint:
        raise SystemExit(
            "Complaint cannot be blank."
        )

    supplier_id = input(
        "Supplier ID (optional): "
    ).strip()

    priority = input(
        "Known priority "
        "(low/medium/high/critical, optional): "
    ).strip()

    report = resolve_complaint(
        complaint=complaint,
        supplier_id=supplier_id,
        provided_priority=priority
    )

    print(
        "\n" +
        "=" * 80
    )

    print(
        "STRUCTURED RESOLUTION REPORT"
    )

    print(
        "=" * 80
    )

    print(
        json.dumps(
            report,
            indent=2
        )
    )


if __name__ == "__main__":
    main()
