import pandas as pd
import streamlit as st

from common import ROOT
from task2_predict import classify_complaint


st.set_page_config(
    page_title="AgriChain Complaint Classifier",
    page_icon="🧠",
    layout="centered"
)

st.title("AgriChain AI — Complaint Classifier")
st.caption("Real-time categorization using MiniLM sentence embeddings and the trained ANN.")

complaint = st.text_area(
    "Complaint text",
    height=180,
    placeholder=(
        "Example: The invoice price is higher than the contracted price "
        "and we need a corrected invoice."
    )
)

if st.button(
    "Classify Complaint",
    type="primary",
    use_container_width=True,
    disabled=not complaint.strip()
):
    try:
        result = classify_complaint(complaint)

        st.success(
            f"Predicted category: **{result['predicted_category']}**"
        )

        st.metric(
            "Model confidence",
            f"{result['confidence']:.1%}"
        )

        st.subheader("Top 3 Predictions")

        top3 = pd.DataFrame(result["top_3"])
        top3["confidence"] = (
            top3["confidence"] * 100
        ).round(2)

        top3 = top3.rename(
            columns={"confidence": "confidence_pct"}
        )

        st.dataframe(
            top3,
            use_container_width=True,
            hide_index=True
        )

        st.bar_chart(
            top3.set_index("category")["confidence_pct"]
        )

    except Exception as exc:
        st.exception(exc)

with st.expander("Model architecture"):
    st.markdown(
        """
        **Pipeline**

        `Complaint text → all-MiniLM-L6-v2 → ANN → 8-class softmax`

        The prediction shown here comes from the trained Task 2 model artifacts.
        """
    )
