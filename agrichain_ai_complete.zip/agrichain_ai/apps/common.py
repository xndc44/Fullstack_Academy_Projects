from pathlib import Path
import sys

APP_DIR = Path(__file__).resolve().parent
ROOT = APP_DIR.parent

if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

DATA_PROCESSED = ROOT / "data" / "processed"
MODELS = ROOT / "models"
ARTIFACTS = ROOT / "artifacts"
