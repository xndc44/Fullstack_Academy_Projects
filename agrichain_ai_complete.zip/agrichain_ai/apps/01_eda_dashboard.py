from pathlib import Path

import pandas as pd
import plotly.express as px
import streamlit as st

from common import DATA_PROCESSED


st.set_page_config(
    page_title="AgriChain EDA Dashboard",
    page_icon="📊",
    layout="wide"
)

st.title("AgriChain AI — EDA Dashboard")
st.caption("Complaint trends, categories, regions, channels, priorities and time patterns.")


@st.cache_data
def load_data():
    train_path = DATA_PROCESSED / "complaints_train_processed.csv"
    test_path = DATA_PROCESSED / "complaints_test_processed.csv"

    if not train_path.exists() or not test_path.exists():
        raise FileNotFoundError(
            "Task 1 processed files are missing. "
            "Run task1_agrichain_exact.py first."
        )

    train = pd.read_csv(train_path)
    test = pd.read_csv(test_path)

    train["dataset"] = "Train"
    test["dataset"] = "Test"

    df = pd.concat([train, test], ignore_index=True)
    df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
    return train, test, df


try:
    train, test, df = load_data()
except Exception as exc:
    st.error(str(exc))
    st.stop()

m1, m2, m3, m4 = st.columns(4)
m1.metric("Total complaints", f"{len(df):,}")
m2.metric("Training records", f"{len(train):,}")
m3.metric("Test records", f"{len(test):,}")
m4.metric("Categories", df["category"].nunique())

st.divider()

left, right = st.columns(2)

with left:
    category_counts = (
        df["category"]
        .value_counts()
        .rename_axis("category")
        .reset_index(name="count")
    )
    fig = px.bar(
        category_counts,
        x="category",
        y="count",
        title="Complaint Frequency by Category"
    )
    st.plotly_chart(fig, use_container_width=True)

with right:
    priority_counts = (
        df["priority"]
        .value_counts()
        .rename_axis("priority")
        .reset_index(name="count")
    )
    fig = px.pie(
        priority_counts,
        names="priority",
        values="count",
        title="Complaint Priority Distribution"
    )
    st.plotly_chart(fig, use_container_width=True)

left, right = st.columns(2)

with left:
    region_counts = (
        df["region"]
        .value_counts()
        .rename_axis("region")
        .reset_index(name="count")
    )
    fig = px.bar(
        region_counts,
        x="region",
        y="count",
        title="Complaints by Region"
    )
    st.plotly_chart(fig, use_container_width=True)

with right:
    channel_counts = (
        df["channel"]
        .value_counts()
        .rename_axis("channel")
        .reset_index(name="count")
    )
    fig = px.bar(
        channel_counts,
        x="channel",
        y="count",
        title="Complaints by Channel"
    )
    st.plotly_chart(fig, use_container_width=True)

time_df = df.dropna(subset=["timestamp"]).copy()
time_df["month"] = time_df["timestamp"].dt.to_period("M").astype(str)

monthly = (
    time_df.groupby("month")
    .size()
    .reset_index(name="complaints")
)

fig = px.line(
    monthly,
    x="month",
    y="complaints",
    markers=True,
    title="Complaint Volume Over Time"
)
st.plotly_chart(fig, use_container_width=True)

st.subheader("Category × Region")
cross_region = pd.crosstab(df["category"], df["region"])
st.dataframe(cross_region, use_container_width=True)

st.subheader("Category × Channel")
cross_channel = pd.crosstab(df["category"], df["channel"])
st.dataframe(cross_channel, use_container_width=True)

st.subheader("Class Balance")
balance = (
    train["category"]
    .value_counts()
    .rename_axis("category")
    .reset_index(name="train_count")
)
balance["share_pct"] = (
    100 * balance["train_count"] / balance["train_count"].sum()
)
st.dataframe(balance, use_container_width=True)

st.subheader("Complaint Explorer")

categories = sorted(df["category"].dropna().unique())
regions = sorted(df["region"].dropna().unique())
channels = sorted(df["channel"].dropna().unique())

f1, f2, f3 = st.columns(3)
selected_categories = f1.multiselect("Category", categories)
selected_regions = f2.multiselect("Region", regions)
selected_channels = f3.multiselect("Channel", channels)

filtered = df.copy()

if selected_categories:
    filtered = filtered[filtered["category"].isin(selected_categories)]
if selected_regions:
    filtered = filtered[filtered["region"].isin(selected_regions)]
if selected_channels:
    filtered = filtered[filtered["channel"].isin(selected_channels)]

display_cols = [
    "complaint_id",
    "timestamp",
    "channel",
    "complaint_text",
    "category",
    "priority",
    "supplier_id",
    "product_category",
    "region",
    "order_id",
]

st.dataframe(
    filtered[display_cols],
    use_container_width=True,
    height=450
)
