import json

import pandas as pd
import streamlit as st

from common import ROOT
from task3_agents import resolve_complaint


st.set_page_config(
    page_title="AgriChain Multi-Agent System",
    page_icon="🤖",
    layout="wide"
)

st.title("AgriChain AI — LangGraph Multi-Agent Resolution")
st.caption(
    "End-to-end complaint classification, severity analysis, RAG investigation, "
    "resolution planning, communication and escalation."
)

with st.form("complaint_form"):
    complaint = st.text_area(
        "Complaint",
        height=180,
        placeholder=(
            "Example: Our produce shipment arrived five days late, "
            "several cartons were damaged, and the carrier has not responded."
        )
    )

    c1, c2, c3 = st.columns(3)

    complaint_id = c1.text_input(
        "Complaint ID (optional)"
    )
    customer_id = c2.text_input(
        "Customer ID (optional)"
    )
    supplier_id = c3.text_input(
        "Supplier ID (optional)"
    )

    c4, c5, c6 = st.columns(3)

    order_id = c4.text_input(
        "Order ID (optional)"
    )
    region = c5.text_input(
        "Region (optional)"
    )
    channel = c6.text_input(
        "Channel (optional)"
    )

    priority = st.selectbox(
        "Known priority (optional)",
        [
            "",
            "low",
            "medium",
            "high",
            "critical"
        ]
    )

    submitted = st.form_submit_button(
        "Run Multi-Agent Workflow",
        type="primary",
        use_container_width=True
    )

if submitted:
    if not complaint.strip():
        st.error("Enter a complaint.")
        st.stop()

    try:
        with st.spinner(
            "Running classifier, RAG retrieval and five-agent workflow..."
        ):
            report = resolve_complaint(
                complaint=complaint,
                complaint_id=complaint_id,
                customer_id=customer_id,
                supplier_id=supplier_id,
                order_id=order_id,
                region=region,
                channel=channel,
                provided_priority=priority,
            )

        classification = report["classification"]
        severity = report["severity_analysis"]
        investigation = report["investigation"]
        resolution = report["resolution"]
        communication = report["customer_communication"]
        escalation = report["escalation"]

        m1, m2, m3, m4 = st.columns(4)

        m1.metric(
            "Category",
            classification["category"]
        )

        m2.metric(
            "Classifier confidence",
            f"{classification['confidence']:.1%}"
        )

        m3.metric(
            "Severity",
            severity["severity"]
        )

        m4.metric(
            "Escalation",
            (
                escalation["level"]
                if escalation["required"]
                else "NONE"
            )
        )

        st.divider()

        tab1, tab2, tab3, tab4, tab5 = st.tabs([
            "Analyzer",
            "Investigator",
            "Planner",
            "Communicator",
            "Escalation"
        ])

        with tab1:
            st.subheader("Severity Assessment")
            st.write(severity["rationale"])

            if severity["risk_factors"]:
                st.markdown("**Risk factors**")
                for item in severity["risk_factors"]:
                    st.write(f"- {item}")

            st.write(
                "**Immediate action required:**",
                (
                    "Yes"
                    if severity["immediate_action_required"]
                    else "No"
                )
            )

        with tab2:
            st.subheader("Investigation Summary")
            st.write(investigation["summary"])

            if investigation["key_findings"]:
                st.markdown("**Key findings**")
                for item in investigation["key_findings"]:
                    st.write(f"- {item}")

            if investigation["missing_information"]:
                st.markdown("**Missing information**")
                for item in investigation["missing_information"]:
                    st.write(f"- {item}")

            st.markdown("**Relevant knowledge documents**")
            st.write(
                ", ".join(
                    investigation["relevant_doc_ids"]
                ) or "None"
            )

            evidence = investigation["retrieved_evidence"]

            if evidence:
                evidence_df = pd.DataFrame([
                    {
                        "rank": item.get("rank"),
                        "doc_id": item.get("doc_id"),
                        "doc_type": item.get("doc_type"),
                        "category": item.get("category"),
                        "similarity": round(
                            item.get("similarity_score", 0),
                            4
                        ),
                    }
                    for item in evidence
                ])

                st.dataframe(
                    evidence_df,
                    use_container_width=True,
                    hide_index=True
                )

        with tab3:
            st.subheader("Resolution Objective")
            st.write(resolution["objective"])

            st.subheader("Resolution Steps")

            for step in resolution["steps"]:
                with st.container(border=True):
                    st.markdown(
                        f"### Step {step['step_number']}"
                    )
                    st.write(step["action"])
                    st.caption(
                        f"Owner: {step['owner']} | "
                        f"Target: {step['target_time']}"
                    )
                    st.write(
                        f"**Verification:** {step['verification']}"
                    )

            if resolution["proposed_compensation"]:
                st.info(
                    "Proposed compensation: "
                    + resolution["proposed_compensation"]
                )

            st.markdown("**Closure criteria**")
            for item in resolution["closure_criteria"]:
                st.write(f"- {item}")

        with tab4:
            st.subheader(
                communication["subject"]
            )
            st.info(
                communication["message"]
            )

            if communication["commitments"]:
                st.markdown("**Customer commitments**")
                for item in communication["commitments"]:
                    st.write(f"- {item}")

        with tab5:
            if escalation["required"]:
                st.error(
                    f"Human escalation required: "
                    f"{escalation['level']}"
                )
            else:
                st.success(
                    "No mandatory escalation identified."
                )

            st.write(
                escalation["rationale"]
            )

            if escalation["triggers"]:
                st.markdown("**Escalation triggers**")
                for item in escalation["triggers"]:
                    st.write(f"- {item}")

        st.divider()
        st.subheader("Structured Resolution Report")

        st.json(report)

        st.download_button(
            "Download JSON Report",
            data=json.dumps(
                report,
                indent=2
            ),
            file_name=(
                f"{complaint_id or 'agrichain'}"
                "_resolution_report.json"
            ),
            mime="application/json",
            use_container_width=True
        )

    except Exception as exc:
        st.exception(exc)
