import os

import pandas as pd
import streamlit as st
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI

from common import ROOT
from task2_rag_retriever import retrieve


load_dotenv(ROOT / ".env")

st.set_page_config(
    page_title="AgriChain RAG Assistant",
    page_icon="🔎",
    layout="wide"
)

st.title("AgriChain AI — RAG Knowledge Assistant")
st.caption(
    "Semantic search across resolution guides, SOPs and supplier information."
)

query = st.text_area(
    "Ask the knowledge base",
    height=120,
    placeholder=(
        "Example: What should we do when a delivery is more than "
        "three days late?"
    )
)

k = st.slider(
    "Number of retrieved documents",
    min_value=1,
    max_value=10,
    value=5
)

generate_answer = st.checkbox(
    "Generate a grounded natural-language answer",
    value=True
)

if st.button(
    "Search Knowledge Base",
    type="primary",
    use_container_width=True,
    disabled=not query.strip()
):
    try:
        hits = retrieve(query, k=k)

        if not hits:
            st.warning("No knowledge-base results were returned.")
            st.stop()

        if generate_answer:
            if not os.getenv("OPENAI_API_KEY"):
                st.warning(
                    "OPENAI_API_KEY is not configured, so only retrieval "
                    "results are shown."
                )
            else:
                context = "\n\n".join(
                    (
                        f"[{hit['doc_id']}] "
                        f"{hit['doc_type']} | {hit['category']}\n"
                        f"{hit['content']}"
                    )
                    for hit in hits
                )

                llm = ChatOpenAI(
                    model=os.getenv(
                        "OPENAI_MODEL",
                        "gpt-5.4-mini"
                    ),
                    temperature=0
                )

                response = llm.invoke([
                    (
                        "system",
                        (
                            "You are the AgriChain RAG Knowledge Assistant. "
                            "Answer only from the supplied retrieved context. "
                            "Do not invent policies, compensation, timelines, "
                            "supplier facts, or document IDs. "
                            "When making a factual claim, reference the relevant "
                            "KB document ID in square brackets. "
                            "If the context is insufficient, say so."
                        )
                    ),
                    (
                        "human",
                        f"Question:\n{query}\n\nRetrieved context:\n{context}"
                    )
                ])

                st.subheader("Grounded Answer")
                st.write(response.content)

        st.subheader("Retrieved Evidence")

        evidence_table = pd.DataFrame([
            {
                "rank": hit["rank"],
                "doc_id": hit["doc_id"],
                "doc_type": hit["doc_type"],
                "category": hit["category"],
                "similarity": round(
                    hit["similarity_score"], 4
                ),
                "last_updated": hit["last_updated"],
            }
            for hit in hits
        ])

        st.dataframe(
            evidence_table,
            use_container_width=True,
            hide_index=True
        )

        for hit in hits:
            with st.expander(
                f"#{hit['rank']} {hit['doc_id']} — "
                f"{hit['category']} "
                f"({hit['similarity_score']:.3f})"
            ):
                st.write(hit["content"])
                st.caption(
                    f"Type: {hit['doc_type']} | "
                    f"Last updated: {hit['last_updated']}"
                )

    except Exception as exc:
        st.exception(exc)
