"""
AgriChain AI - Task 2C
Simple semantic retrieval evaluation.

This creates a reproducible test set from categories explicitly represented
in the supplied knowledge_base.json.

Metrics:
    Hit@1
    Hit@3
    Mean Reciprocal Rank (MRR)

For supplier queries, exact expected doc_id retrieval is checked.
For complaint/policy queries, expected category is checked.
"""

from task2_rag_retriever import retrieve


TEST_QUERIES = [
    {
        "query": "shipment arrived several days late",
        "expected_category": "Delivery Delay",
    },
    {
        "query": "goods arrived crushed and damaged",
        "expected_category": "Damaged Goods",
    },
    {
        "query": "invoice amount does not match contract price",
        "expected_category": "Pricing Error",
    },
    {
        "query": "part of the order is missing",
        "expected_category": "Missing Items",
    },
    {
        "query": "customer cannot get responses from support",
        "expected_category": "Poor Communication",
    },
    {
        "query": "product quality is poor and may affect the batch",
        "expected_category": "Quality Issues",
    },
    {
        "query": "shipment paperwork and certificates are incorrect",
        "expected_category": "Documentation Error",
    },
    {
        "query": "customer reports rude and unprofessional service",
        "expected_category": "Service Complaint",
    },
    {
        "query": "critical complaint needs manager escalation",
        "expected_category": "General",
    },
    {
        "query": "supplier SUP-6421 performance",
        "expected_doc_id": "KB-00078",
    },
]


def is_relevant(result, test_case):
    if "expected_doc_id" in test_case:
        return (
            result["doc_id"] ==
            test_case["expected_doc_id"]
        )

    return (
        result["category"] ==
        test_case["expected_category"]
    )


def main():
    hit1 = 0
    hit3 = 0
    reciprocal_ranks = []

    for case in TEST_QUERIES:
        hits = retrieve(
            case["query"],
            k=5
        )

        relevant_ranks = [
            i
            for i, hit in enumerate(hits, start=1)
            if is_relevant(hit, case)
        ]

        first_rank = (
            relevant_ranks[0]
            if relevant_ranks
            else None
        )

        if first_rank == 1:
            hit1 += 1

        if (
            first_rank is not None
            and first_rank <= 3
        ):
            hit3 += 1

        reciprocal_ranks.append(
            1 / first_rank
            if first_rank is not None
            else 0
        )

        print("\nQuery:", case["query"])
        print("First relevant rank:", first_rank)

        for hit in hits[:3]:
            print(
                f"  {hit['rank']}. "
                f"{hit['doc_id']} | "
                f"{hit['category']} | "
                f"{hit['similarity_score']:.4f}"
            )

    n = len(TEST_QUERIES)

    print("\n" + "=" * 60)
    print("RAG RETRIEVAL METRICS")
    print("=" * 60)

    print(
        f"Hit@1: {hit1 / n:.3f}"
    )

    print(
        f"Hit@3: {hit3 / n:.3f}"
    )

    print(
        "MRR:   "
        f"{sum(reciprocal_ranks) / n:.3f}"
    )


if __name__ == "__main__":
    main()
