"""
AgriChain AI - Task 2B
FAISS Retrieval-Augmented Generation Knowledge Base

Input:
    data/knowledge/knowledge_base.json

Output:
    artifacts/faiss/knowledge.index
    artifacts/faiss/knowledge_metadata.json
    artifacts/faiss/rag_build_summary.json

The knowledge-base records already contain short, self-contained content,
so each record is indexed as one semantic unit rather than arbitrarily
splitting it into chunks.
"""

from pathlib import Path
import json

import numpy as np
import pandas as pd
import faiss
from sentence_transformers import SentenceTransformer


# -------------------------------------------------------------------
# CONFIG
# -------------------------------------------------------------------

EMBEDDING_MODEL_NAME = (
    "sentence-transformers/all-MiniLM-L6-v2"
)

BASE_DIR = Path(__file__).resolve().parent

KB_FILE = (
    BASE_DIR /
    "data" /
    "knowledge" /
    "knowledge_base.json"
)

FAISS_DIR = (
    BASE_DIR /
    "artifacts" /
    "faiss"
)

INDEX_FILE = (
    FAISS_DIR /
    "knowledge.index"
)

METADATA_FILE = (
    FAISS_DIR /
    "knowledge_metadata.json"
)

SUMMARY_FILE = (
    FAISS_DIR /
    "rag_build_summary.json"
)


# -------------------------------------------------------------------
# LOAD AND CLEAN KNOWLEDGE BASE
# -------------------------------------------------------------------

def load_knowledge_base():
    with open(
        KB_FILE,
        "r",
        encoding="utf-8"
    ) as f:
        records = json.load(f)

    df = pd.DataFrame(records)

    required = {
        "doc_id",
        "doc_type",
        "category",
        "content",
        "last_updated"
    }

    missing = required - set(df.columns)

    if missing:
        raise ValueError(
            f"Knowledge base missing fields: {missing}"
        )

    df["last_updated"] = pd.to_datetime(
        df["last_updated"],
        errors="coerce"
    )

    df["content"] = (
        df["content"]
        .astype(str)
        .str.strip()
    )

    # The supplied KB contains repeated general SOP text
    # under different IDs/dates. Keep the most recent copy
    # of identical content so duplicates do not dominate retrieval.
    before = len(df)

    df = (
        df.sort_values(
            "last_updated",
            ascending=False
        )
        .drop_duplicates(
            subset=["content"],
            keep="first"
        )
        .reset_index(drop=True)
    )

    duplicates_removed = before - len(df)

    return df, duplicates_removed


# -------------------------------------------------------------------
# EMBEDDING TEXT
# -------------------------------------------------------------------

def build_index_text(row):
    """
    Include metadata in the embedding representation so queries such as
    'delivery delay policy' or 'supplier SUP-6421 performance' retrieve
    the correct record more reliably.
    """
    return (
        f"Document type: {row['doc_type']}. "
        f"Category: {row['category']}. "
        f"{row['content']}"
    )


# -------------------------------------------------------------------
# BUILD FAISS INDEX
# -------------------------------------------------------------------

def build_faiss_index():
    FAISS_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    df, duplicates_removed = (
        load_knowledge_base()
    )

    df["index_text"] = df.apply(
        build_index_text,
        axis=1
    )

    model = SentenceTransformer(
        EMBEDDING_MODEL_NAME
    )

    print(
        f"Embedding {len(df)} unique "
        "knowledge-base records..."
    )

    embeddings = model.encode(
        df["index_text"].tolist(),
        batch_size=64,
        show_progress_bar=True,
        normalize_embeddings=True,
        convert_to_numpy=True
    ).astype("float32")

    dimension = embeddings.shape[1]

    # Normalized vectors + inner product = cosine similarity.
    index = faiss.IndexFlatIP(
        dimension
    )

    index.add(
        embeddings
    )

    faiss.write_index(
        index,
        str(INDEX_FILE)
    )

    metadata = []

    for _, row in df.iterrows():
        metadata.append({
            "doc_id": row["doc_id"],
            "doc_type": row["doc_type"],
            "category": row["category"],
            "content": row["content"],
            "last_updated": (
                row["last_updated"].strftime("%Y-%m-%d")
                if pd.notna(row["last_updated"])
                else None
            )
        })

    with open(
        METADATA_FILE,
        "w",
        encoding="utf-8"
    ) as f:
        json.dump(
            metadata,
            f,
            indent=2
        )

    summary = {
        "raw_documents": int(
            len(df) + duplicates_removed
        ),

        "indexed_unique_documents": int(
            len(df)
        ),

        "duplicate_content_removed": int(
            duplicates_removed
        ),

        "embedding_model": (
            EMBEDDING_MODEL_NAME
        ),

        "embedding_dimension": int(
            dimension
        ),

        "faiss_index": (
            "IndexFlatIP"
        ),

        "similarity": (
            "cosine similarity "
            "(normalized embeddings + inner product)"
        ),

        "document_types": (
            df["doc_type"]
            .value_counts()
            .to_dict()
        ),

        "categories": (
            df["category"]
            .value_counts()
            .to_dict()
        )
    }

    with open(
        SUMMARY_FILE,
        "w",
        encoding="utf-8"
    ) as f:
        json.dump(
            summary,
            f,
            indent=2
        )

    print("\nFAISS index complete.")
    print(
        f"Raw documents: {summary['raw_documents']}"
    )
    print(
        "Duplicate text removed:",
        duplicates_removed
    )
    print(
        "Indexed documents:",
        len(df)
    )
    print(
        "Embedding dimension:",
        dimension
    )


if __name__ == "__main__":
    build_faiss_index()
