"""
AgriChain AI - Task 3
LangGraph Multi-Agent Complaint Resolution System

Requires Task 2 artifacts:
    models/complaint_ann.keras
    models/label_encoder.joblib
    artifacts/faiss/knowledge.index
    artifacts/faiss/knowledge_metadata.json

Requires Task 2 modules in the same project:
    task2_predict.py
    task2_rag_retriever.py

Five required agents:
    1. Analyzer Agent
    2. Investigator Agent
    3. Planner Agent
    4. Communicator Agent
    5. Escalation Manager

Additional workflow nodes:
    - ANN Classifier
    - Final Report Builder
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Literal, Optional, TypedDict
from datetime import datetime, timezone
import json
import os
import re

from dotenv import load_dotenv
from pydantic import BaseModel, Field
from langchain_openai import ChatOpenAI
from langgraph.graph import StateGraph, START, END

from task2_predict import classify_complaint
from task2_rag_retriever import retrieve


# -------------------------------------------------------------------
# ENVIRONMENT / CONFIG
# -------------------------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")

OPENAI_MODEL = os.getenv(
    "OPENAI_MODEL",
    "gpt-5.4-mini"
)

RAG_TOP_K = int(
    os.getenv("RAG_TOP_K", "5")
)

LOW_CONFIDENCE_THRESHOLD = float(
    os.getenv("LOW_CONFIDENCE_THRESHOLD", "0.60")
)


# -------------------------------------------------------------------
# STRUCTURED LLM OUTPUT SCHEMAS
# -------------------------------------------------------------------

SeverityLevel = Literal[
    "LOW",
    "MEDIUM",
    "HIGH",
    "CRITICAL"
]


class SeverityAssessment(BaseModel):
    severity: SeverityLevel = Field(
        description="Overall complaint severity."
    )

    rationale: str = Field(
        description="Concise evidence-based rationale."
    )

    risk_factors: List[str] = Field(
        default_factory=list,
        description=(
            "Specific factors increasing severity, "
            "such as perishability, safety, financial impact, "
            "repeat failure, regulatory exposure, or operational disruption."
        )
    )

    immediate_action_required: bool = Field(
        description=(
            "Whether action should begin immediately "
            "rather than through routine handling."
        )
    )


class InvestigationAssessment(BaseModel):
    summary: str = Field(
        description=(
            "What the retrieved policy, SOP, supplier information, "
            "or resolution guidance says about this complaint."
        )
    )

    relevant_doc_ids: List[str] = Field(
        default_factory=list,
        description="Relevant document IDs from retrieved evidence only."
    )

    key_findings: List[str] = Field(
        default_factory=list,
        description="Important evidence-supported findings."
    )

    missing_information: List[str] = Field(
        default_factory=list,
        description=(
            "Facts still needed to fully investigate the complaint."
        )
    )


class ResolutionStep(BaseModel):
    step_number: int

    action: str

    owner: str = Field(
        description=(
            "Responsible business function, e.g. Logistics, "
            "Customer Success, Finance, QA, Warehouse, Operations."
        )
    )

    target_time: str = Field(
        description=(
            "Expected timeframe grounded in retrieved SOPs "
            "when one is available."
        )
    )

    verification: str = Field(
        description="How completion of this step should be verified."
    )


class ResolutionPlan(BaseModel):
    objective: str

    steps: List[ResolutionStep]

    proposed_compensation: Optional[str] = Field(
        default=None,
        description=(
            "Compensation supported by retrieved guidance. "
            "Null if evidence does not support compensation."
        )
    )

    closure_criteria: List[str]


class CustomerCommunication(BaseModel):
    subject: str

    message: str

    commitments: List[str] = Field(
        default_factory=list
    )


class EscalationDecision(BaseModel):
    escalate: bool

    escalation_level: Literal[
        "NONE",
        "SUPERVISOR",
        "OPERATIONS_MANAGER",
        "SPECIALIST_REVIEW"
    ]

    rationale: str

    triggers: List[str] = Field(
        default_factory=list
    )


# -------------------------------------------------------------------
# LANGGRAPH STATE
# -------------------------------------------------------------------

class ComplaintState(TypedDict, total=False):
    # Input
    complaint: str
    complaint_id: str
    customer_id: str
    supplier_id: str
    order_id: str
    region: str
    channel: str
    provided_priority: str

    # Classifier
    predicted_category: str
    classifier_confidence: float
    classifier_top_3: List[Dict[str, Any]]

    # Analyzer
    severity: str
    severity_rationale: str
    risk_factors: List[str]
    immediate_action_required: bool

    # Investigator
    retrieved_evidence: List[Dict[str, Any]]
    investigation_summary: str
    relevant_doc_ids: List[str]
    investigation_findings: List[str]
    missing_information: List[str]

    # Planner
    resolution_objective: str
    resolution_steps: List[Dict[str, Any]]
    proposed_compensation: Optional[str]
    closure_criteria: List[str]

    # Communicator
    communication_subject: str
    customer_response: str
    customer_commitments: List[str]

    # Escalation
    escalation_required: bool
    escalation_level: str
    escalation_rationale: str
    escalation_triggers: List[str]

    # Final output
    final_report: Dict[str, Any]


# -------------------------------------------------------------------
# MODEL
# -------------------------------------------------------------------

def get_llm():
    if not os.getenv("OPENAI_API_KEY"):
        raise RuntimeError(
            "OPENAI_API_KEY is missing. "
            "Create a .env file from .env.example."
        )

    return ChatOpenAI(
        model=OPENAI_MODEL,
        temperature=0
    )


# -------------------------------------------------------------------
# HELPERS
# -------------------------------------------------------------------

def safe_text(value: Any) -> str:
    if value is None:
        return ""
    return str(value).strip()


def evidence_to_prompt(
    evidence: List[Dict[str, Any]]
) -> str:
    sections = []

    for item in evidence:
        sections.append(
            "\n".join([
                f"DOC_ID: {item.get('doc_id', '')}",
                f"DOC_TYPE: {item.get('doc_type', '')}",
                f"CATEGORY: {item.get('category', '')}",
                f"LAST_UPDATED: {item.get('last_updated', '')}",
                f"SIMILARITY: {item.get('similarity_score', 0):.4f}",
                f"CONTENT: {item.get('content', '')}",
            ])
        )

    return "\n\n---\n\n".join(sections)


def supplier_ids_in_text(text: str) -> List[str]:
    return sorted(
        set(
            re.findall(
                r"\bSUP-\d+\b",
                text.upper()
            )
        )
    )


# -------------------------------------------------------------------
# NODE 0 - ANN CLASSIFIER
# -------------------------------------------------------------------

def classifier_node(
    state: ComplaintState
) -> Dict[str, Any]:
    prediction = classify_complaint(
        state["complaint"]
    )

    return {
        "predicted_category": (
            prediction["predicted_category"]
        ),
        "classifier_confidence": (
            prediction["confidence"]
        ),
        "classifier_top_3": (
            prediction["top_3"]
        )
    }


# -------------------------------------------------------------------
# AGENT 1 - ANALYZER
# -------------------------------------------------------------------

def analyzer_agent(
    state: ComplaintState
) -> Dict[str, Any]:
    llm = get_llm().with_structured_output(
        SeverityAssessment,
        method="json_schema"
    )

    provided_priority = safe_text(
        state.get("provided_priority")
    )

    prompt = f"""
You are the AgriChain Analyzer Agent.

Assess the severity of this agricultural supply-chain complaint.

Complaint:
{state["complaint"]}

ANN predicted category:
{state.get("predicted_category", "")}

ANN confidence:
{state.get("classifier_confidence", 0):.4f}

Provided source priority, if any:
{provided_priority or "Not provided"}

Use these principles:
- LOW: minor inconvenience, little operational or financial impact.
- MEDIUM: meaningful disruption requiring action but no urgent high-risk signal.
- HIGH: major financial/operational/customer impact, significant quality concern,
  repeat failure, substantial perishability risk, or urgent business impact.
- CRITICAL: safety/regulatory risk, widespread product/batch risk, severe business
  interruption, or a situation requiring immediate manager intervention.

Do not invent facts not present in the complaint.
If a source priority is supplied, consider it as evidence but still assess the text.
"""

    result = llm.invoke(prompt)

    return {
        "severity": result.severity,
        "severity_rationale": result.rationale,
        "risk_factors": result.risk_factors,
        "immediate_action_required": (
            result.immediate_action_required
        )
    }


# -------------------------------------------------------------------
# AGENT 2 - INVESTIGATOR
# -------------------------------------------------------------------

def investigator_agent(
    state: ComplaintState
) -> Dict[str, Any]:
    supplier_id = safe_text(
        state.get("supplier_id")
    )

    discovered_suppliers = supplier_ids_in_text(
        state["complaint"]
    )

    supplier_context = (
        supplier_id or
        (
            discovered_suppliers[0]
            if discovered_suppliers
            else ""
        )
    )

    # Query includes classifier and severity context.
    query = (
        f"{state.get('predicted_category', '')}. "
        f"Severity {state.get('severity', '')}. "
        f"{state['complaint']} "
    )

    if supplier_context:
        query += (
            f" Supplier {supplier_context}."
        )

    evidence = retrieve(
        query,
        k=RAG_TOP_K
    )

    evidence_text = evidence_to_prompt(
        evidence
    )

    llm = get_llm().with_structured_output(
        InvestigationAssessment,
        method="json_schema"
    )

    prompt = f"""
You are the AgriChain Investigator Agent.

Your job is to investigate the complaint using ONLY the retrieved knowledge-base
evidence supplied below.

Complaint:
{state["complaint"]}

Predicted category:
{state.get("predicted_category", "")}

Severity:
{state.get("severity", "")}

Retrieved evidence:
{evidence_text}

Rules:
1. Do not invent policies, supplier facts, compensation, SLAs, or timelines.
2. Only cite DOC_ID values that actually appear in the retrieved evidence.
3. If the evidence does not answer a question, place that fact in missing_information.
4. Distinguish general SOPs from category-specific resolution guidance and
   supplier-specific records.
"""

    result = llm.invoke(prompt)

    retrieved_ids = {
        item.get("doc_id")
        for item in evidence
    }

    # Prevent hallucinated doc IDs from surviving into state.
    valid_doc_ids = [
        doc_id
        for doc_id in result.relevant_doc_ids
        if doc_id in retrieved_ids
    ]

    return {
        "retrieved_evidence": evidence,
        "investigation_summary": (
            result.summary
        ),
        "relevant_doc_ids": valid_doc_ids,
        "investigation_findings": (
            result.key_findings
        ),
        "missing_information": (
            result.missing_information
        )
    }


# -------------------------------------------------------------------
# AGENT 3 - PLANNER
# -------------------------------------------------------------------

def planner_agent(
    state: ComplaintState
) -> Dict[str, Any]:
    evidence_text = evidence_to_prompt(
        state.get(
            "retrieved_evidence",
            []
        )
    )

    llm = get_llm().with_structured_output(
        ResolutionPlan,
        method="json_schema"
    )

    prompt = f"""
You are the AgriChain Planner Agent.

Develop an operational resolution plan.

Complaint:
{state["complaint"]}

Category:
{state.get("predicted_category", "")}

Severity:
{state.get("severity", "")}

Investigation:
{state.get("investigation_summary", "")}

Missing information:
{state.get("missing_information", [])}

Retrieved policy / SOP / supplier evidence:
{evidence_text}

Rules:
- Every material action should be supported by the complaint or retrieved evidence.
- Use policy/SOP timelines when present.
- Do not promise compensation outside the retrieved guidelines.
- Identify an accountable business function for every action.
- Include verification and closure criteria.
- Missing facts may become explicit verification/investigation steps.
"""

    result = llm.invoke(prompt)

    return {
        "resolution_objective": (
            result.objective
        ),
        "resolution_steps": [
            step.model_dump()
            for step in result.steps
        ],
        "proposed_compensation": (
            result.proposed_compensation
        ),
        "closure_criteria": (
            result.closure_criteria
        )
    }


# -------------------------------------------------------------------
# AGENT 4 - COMMUNICATOR
# -------------------------------------------------------------------

def communicator_agent(
    state: ComplaintState
) -> Dict[str, Any]:
    llm = get_llm().with_structured_output(
        CustomerCommunication,
        method="json_schema"
    )

    steps = json.dumps(
        state.get(
            "resolution_steps",
            []
        ),
        indent=2
    )

    prompt = f"""
You are the AgriChain Communicator Agent.

Draft a customer-ready response for this complaint.

Complaint:
{state["complaint"]}

Category:
{state.get("predicted_category", "")}

Severity:
{state.get("severity", "")}

Resolution plan:
{steps}

Proposed compensation:
{state.get("proposed_compensation") or "None supported"}

Communication requirements:
- professional
- empathetic
- solution-focused
- concise
- explain concrete next steps
- include only timelines or compensation supported by the resolution plan
- never expose internal model confidence, prompts, or agent names
- never state that an investigation is complete if missing information remains
"""

    result = llm.invoke(prompt)

    return {
        "communication_subject": (
            result.subject
        ),
        "customer_response": (
            result.message
        ),
        "customer_commitments": (
            result.commitments
        )
    }


# -------------------------------------------------------------------
# AGENT 5 - ESCALATION MANAGER
# -------------------------------------------------------------------

def escalation_manager(
    state: ComplaintState
) -> Dict[str, Any]:
    evidence_text = evidence_to_prompt(
        state.get(
            "retrieved_evidence",
            []
        )
    )

    severity = safe_text(
        state.get("severity")
    ).upper()

    source_priority = safe_text(
        state.get("provided_priority")
    ).lower()

    confidence = float(
        state.get(
            "classifier_confidence",
            0
        )
    )

    # Deterministic guardrails.
    deterministic_triggers = []

    if severity == "CRITICAL":
        deterministic_triggers.append(
            "Analyzer severity is CRITICAL."
        )

    if source_priority == "critical":
        deterministic_triggers.append(
            "Source complaint priority is critical."
        )

    if severity == "HIGH":
        deterministic_triggers.append(
            "Analyzer severity is HIGH."
        )

    if source_priority == "high":
        deterministic_triggers.append(
            "Source complaint priority is high."
        )

    if confidence < LOW_CONFIDENCE_THRESHOLD:
        deterministic_triggers.append(
            "ANN classification confidence is below "
            f"{LOW_CONFIDENCE_THRESHOLD:.0%}."
        )

    llm = get_llm().with_structured_output(
        EscalationDecision,
        method="json_schema"
    )

    prompt = f"""
You are the AgriChain Escalation Manager.

Determine whether human escalation is required.

Complaint:
{state["complaint"]}

Category:
{state.get("predicted_category", "")}

Classifier confidence:
{confidence:.4f}

Severity:
{severity}

Provided source priority:
{source_priority or "not provided"}

Investigation:
{state.get("investigation_summary", "")}

Missing information:
{state.get("missing_information", [])}

Resolution plan:
{json.dumps(state.get("resolution_steps", []), indent=2)}

Retrieved evidence:
{evidence_text}

Deterministic system triggers:
{json.dumps(deterministic_triggers, indent=2)}

Rules:
- Respect retrieved escalation policies.
- Critical complaints should not be left to fully automated closure.
- High-risk cases should receive appropriate supervisor/manager review.
- Low classifier confidence is a reason for specialist/human classification review.
- Do not invent escalation policies that are absent from evidence.
"""

    decision = llm.invoke(prompt)

    # Deterministic safety override: critical/high/low-confidence cases
    # cannot be silently downgraded to no escalation.
    forced = bool(
        deterministic_triggers
    )

    escalate = (
        decision.escalate
        or forced
    )

    level = decision.escalation_level

    if forced and level == "NONE":
        if (
            severity == "CRITICAL"
            or source_priority == "critical"
        ):
            level = "OPERATIONS_MANAGER"

        elif (
            severity == "HIGH"
            or source_priority == "high"
        ):
            level = "SUPERVISOR"

        else:
            level = "SPECIALIST_REVIEW"

    triggers = list(
        dict.fromkeys(
            decision.triggers +
            deterministic_triggers
        )
    )

    rationale = decision.rationale

    if forced and not decision.escalate:
        rationale = (
            rationale +
            " Automated guardrail override applied because "
            + "; ".join(deterministic_triggers)
        )

    return {
        "escalation_required": escalate,
        "escalation_level": level,
        "escalation_rationale": rationale,
        "escalation_triggers": triggers
    }


# -------------------------------------------------------------------
# FINAL STRUCTURED REPORT
# -------------------------------------------------------------------

def report_builder(
    state: ComplaintState
) -> Dict[str, Any]:
    report = {
        "report_version": "1.0",
        "generated_at_utc": (
            datetime.now(
                timezone.utc
            ).isoformat()
        ),

        "case": {
            "complaint_id": state.get(
                "complaint_id",
                ""
            ),
            "customer_id": state.get(
                "customer_id",
                ""
            ),
            "supplier_id": state.get(
                "supplier_id",
                ""
            ),
            "order_id": state.get(
                "order_id",
                ""
            ),
            "region": state.get(
                "region",
                ""
            ),
            "channel": state.get(
                "channel",
                ""
            ),
            "complaint": state["complaint"]
        },

        "classification": {
            "category": state.get(
                "predicted_category"
            ),
            "confidence": state.get(
                "classifier_confidence"
            ),
            "top_3": state.get(
                "classifier_top_3",
                []
            )
        },

        "severity_analysis": {
            "severity": state.get(
                "severity"
            ),
            "rationale": state.get(
                "severity_rationale"
            ),
            "risk_factors": state.get(
                "risk_factors",
                []
            ),
            "immediate_action_required": (
                state.get(
                    "immediate_action_required",
                    False
                )
            )
        },

        "investigation": {
            "summary": state.get(
                "investigation_summary"
            ),
            "relevant_doc_ids": state.get(
                "relevant_doc_ids",
                []
            ),
            "key_findings": state.get(
                "investigation_findings",
                []
            ),
            "missing_information": state.get(
                "missing_information",
                []
            ),
            "retrieved_evidence": state.get(
                "retrieved_evidence",
                []
            )
        },

        "resolution": {
            "objective": state.get(
                "resolution_objective"
            ),
            "steps": state.get(
                "resolution_steps",
                []
            ),
            "proposed_compensation": (
                state.get(
                    "proposed_compensation"
                )
            ),
            "closure_criteria": state.get(
                "closure_criteria",
                []
            )
        },

        "customer_communication": {
            "subject": state.get(
                "communication_subject"
            ),
            "message": state.get(
                "customer_response"
            ),
            "commitments": state.get(
                "customer_commitments",
                []
            )
        },

        "escalation": {
            "required": state.get(
                "escalation_required",
                False
            ),
            "level": state.get(
                "escalation_level",
                "NONE"
            ),
            "rationale": state.get(
                "escalation_rationale",
                ""
            ),
            "triggers": state.get(
                "escalation_triggers",
                []
            )
        }
    }

    return {
        "final_report": report
    }


# -------------------------------------------------------------------
# BUILD LANGGRAPH WORKFLOW
# -------------------------------------------------------------------

def build_complaint_graph():
    workflow = StateGraph(
        ComplaintState
    )

    workflow.add_node(
        "classifier",
        classifier_node
    )

    workflow.add_node(
        "analyzer",
        analyzer_agent
    )

    workflow.add_node(
        "investigator",
        investigator_agent
    )

    workflow.add_node(
        "planner",
        planner_agent
    )

    workflow.add_node(
        "communicator",
        communicator_agent
    )

    workflow.add_node(
        "escalation_manager",
        escalation_manager
    )

    workflow.add_node(
        "report_builder",
        report_builder
    )

    workflow.add_edge(
        START,
        "classifier"
    )

    workflow.add_edge(
        "classifier",
        "analyzer"
    )

    workflow.add_edge(
        "analyzer",
        "investigator"
    )

    workflow.add_edge(
        "investigator",
        "planner"
    )

    workflow.add_edge(
        "planner",
        "communicator"
    )

    workflow.add_edge(
        "communicator",
        "escalation_manager"
    )

    workflow.add_edge(
        "escalation_manager",
        "report_builder"
    )

    workflow.add_edge(
        "report_builder",
        END
    )

    return workflow.compile()


complaint_graph = build_complaint_graph()


# -------------------------------------------------------------------
# PUBLIC ENTRY POINT
# -------------------------------------------------------------------

def resolve_complaint(
    complaint: str,
    complaint_id: str = "",
    customer_id: str = "",
    supplier_id: str = "",
    order_id: str = "",
    region: str = "",
    channel: str = "",
    provided_priority: str = ""
) -> Dict[str, Any]:

    initial_state: ComplaintState = {
        "complaint": complaint,
        "complaint_id": complaint_id,
        "customer_id": customer_id,
        "supplier_id": supplier_id,
        "order_id": order_id,
        "region": region,
        "channel": channel,
        "provided_priority": provided_priority
    }

    result = complaint_graph.invoke(
        initial_state
    )

    return result["final_report"]


if __name__ == "__main__":
    sample = (
        "Our shipment of fresh produce arrived five days late. "
        "Several boxes were wet and damaged, and we have not received "
        "a useful update from the carrier."
    )

    report = resolve_complaint(
        complaint=sample,
        complaint_id="DEMO-001"
    )

    print(
        json.dumps(
            report,
            indent=2
        )
    )
