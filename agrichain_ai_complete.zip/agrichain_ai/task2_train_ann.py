"""
AgriChain AI - Task 2A
MiniLM Sentence Embeddings + ANN Complaint Classifier

Inputs:
    data/processed/complaints_train_processed.csv
    data/processed/complaints_train_balanced.csv   (preferred when available)
    data/processed/complaints_test_processed.csv
    models/label_encoder.joblib                    (from Task 1)

Outputs:
    models/complaint_ann.keras
    models/classifier_metrics.json
    models/classification_report.csv
    models/confusion_matrix.png
    models/training_history.csv
    models/train_embeddings.npy
    models/test_embeddings.npy
"""

from pathlib import Path
import json

import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sentence_transformers import SentenceTransformer
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    ConfusionMatrixDisplay,
    precision_recall_fscore_support,
)
from sklearn.utils.class_weight import compute_class_weight

import tensorflow as tf


# -------------------------------------------------------------------
# CONFIG
# -------------------------------------------------------------------

RANDOM_STATE = 42
EMBEDDING_MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data" / "processed"
MODEL_DIR = BASE_DIR / "models"

TRAIN_ORIGINAL = DATA_DIR / "complaints_train_processed.csv"
TRAIN_BALANCED = DATA_DIR / "complaints_train_balanced.csv"
TEST_FILE = DATA_DIR / "complaints_test_processed.csv"
ENCODER_FILE = MODEL_DIR / "label_encoder.joblib"

MODEL_DIR.mkdir(parents=True, exist_ok=True)

np.random.seed(RANDOM_STATE)
tf.random.set_seed(RANDOM_STATE)


# -------------------------------------------------------------------
# LOAD DATA
# -------------------------------------------------------------------

def load_datasets():
    if TRAIN_BALANCED.exists():
        train_path = TRAIN_BALANCED
        print("Using balanced Task 1 training dataset.")
    else:
        train_path = TRAIN_ORIGINAL
        print(
            "Balanced file not found; using original training dataset "
            "with ANN class weights."
        )

    train = pd.read_csv(train_path)
    test = pd.read_csv(TEST_FILE)

    required = {"clean_text", "category"}

    if not required.issubset(train.columns):
        raise ValueError(
            f"Training file must contain {required}. "
            "Run Task 1 first."
        )

    if not required.issubset(test.columns):
        raise ValueError(
            f"Test file must contain {required}. "
            "Run Task 1 first."
        )

    if not ENCODER_FILE.exists():
        raise FileNotFoundError(
            "models/label_encoder.joblib not found. Run Task 1 first."
        )

    encoder = joblib.load(ENCODER_FILE)

    return train, test, encoder


# -------------------------------------------------------------------
# SENTENCE EMBEDDINGS
# -------------------------------------------------------------------

def create_embeddings(train, test):
    print(f"\nLoading embedding model: {EMBEDDING_MODEL_NAME}")

    embedding_model = SentenceTransformer(
        EMBEDDING_MODEL_NAME
    )

    print("Generating training embeddings...")
    X_train = embedding_model.encode(
        train["clean_text"].fillna("").astype(str).tolist(),
        batch_size=64,
        show_progress_bar=True,
        normalize_embeddings=True,
        convert_to_numpy=True,
    ).astype("float32")

    print("Generating test embeddings...")
    X_test = embedding_model.encode(
        test["clean_text"].fillna("").astype(str).tolist(),
        batch_size=64,
        show_progress_bar=True,
        normalize_embeddings=True,
        convert_to_numpy=True,
    ).astype("float32")

    np.save(
        MODEL_DIR / "train_embeddings.npy",
        X_train
    )

    np.save(
        MODEL_DIR / "test_embeddings.npy",
        X_test
    )

    print(f"Embedding dimension: {X_train.shape[1]}")

    return X_train, X_test


# -------------------------------------------------------------------
# ANN MODEL
# -------------------------------------------------------------------

def build_ann(input_dim, number_of_classes):
    """
    Feed-forward ANN operating on MiniLM sentence embeddings.
    """
    model = tf.keras.Sequential([
        tf.keras.layers.Input(shape=(input_dim,)),

        tf.keras.layers.Dense(
            256,
            activation="relu"
        ),

        tf.keras.layers.BatchNormalization(),

        tf.keras.layers.Dropout(0.30),

        tf.keras.layers.Dense(
            128,
            activation="relu"
        ),

        tf.keras.layers.Dropout(0.20),

        tf.keras.layers.Dense(
            64,
            activation="relu"
        ),

        tf.keras.layers.Dropout(0.10),

        tf.keras.layers.Dense(
            number_of_classes,
            activation="softmax"
        )
    ])

    model.compile(
        optimizer=tf.keras.optimizers.Adam(
            learning_rate=0.001
        ),
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"]
    )

    return model


# -------------------------------------------------------------------
# EVALUATION
# -------------------------------------------------------------------

def evaluate_model(model, X_test, y_test, encoder):
    probabilities = model.predict(
        X_test,
        verbose=0
    )

    predictions = np.argmax(
        probabilities,
        axis=1
    )

    accuracy = accuracy_score(
        y_test,
        predictions
    )

    precision_macro, recall_macro, f1_macro, _ = (
        precision_recall_fscore_support(
            y_test,
            predictions,
            average="macro",
            zero_division=0
        )
    )

    precision_weighted, recall_weighted, f1_weighted, _ = (
        precision_recall_fscore_support(
            y_test,
            predictions,
            average="weighted",
            zero_division=0
        )
    )

    report_dict = classification_report(
        y_test,
        predictions,
        labels=np.arange(len(encoder.classes_)),
        target_names=encoder.classes_,
        output_dict=True,
        zero_division=0
    )

    report_df = pd.DataFrame(
        report_dict
    ).transpose()

    report_df.to_csv(
        MODEL_DIR / "classification_report.csv"
    )

    metrics = {
        "test_samples": int(len(y_test)),
        "accuracy": float(accuracy),

        "macro_precision": float(precision_macro),
        "macro_recall": float(recall_macro),
        "macro_f1": float(f1_macro),

        "weighted_precision": float(precision_weighted),
        "weighted_recall": float(recall_weighted),
        "weighted_f1": float(f1_weighted),

        "target_accuracy_met": bool(
            accuracy >= 0.85
        ),

        "classification_report": report_dict,
    }

    with open(
        MODEL_DIR / "classifier_metrics.json",
        "w",
        encoding="utf-8"
    ) as f:
        json.dump(
            metrics,
            f,
            indent=2
        )

    cm = confusion_matrix(
        y_test,
        predictions,
        labels=np.arange(len(encoder.classes_))
    )

    fig, ax = plt.subplots(
        figsize=(11, 9)
    )

    ConfusionMatrixDisplay(
        confusion_matrix=cm,
        display_labels=encoder.classes_
    ).plot(
        ax=ax,
        xticks_rotation=45,
        colorbar=False,
        values_format="d"
    )

    ax.set_title(
        "AgriChain ANN Complaint Classifier\nConfusion Matrix"
    )

    plt.tight_layout()

    plt.savefig(
        MODEL_DIR / "confusion_matrix.png",
        dpi=180
    )

    plt.close()

    print("\n" + "=" * 70)
    print("TEST SET PERFORMANCE")
    print("=" * 70)

    print(
        classification_report(
            y_test,
            predictions,
            labels=np.arange(len(encoder.classes_)),
            target_names=encoder.classes_,
            zero_division=0
        )
    )

    print(f"Accuracy:           {accuracy:.4f}")
    print(f"Macro Precision:    {precision_macro:.4f}")
    print(f"Macro Recall:       {recall_macro:.4f}")
    print(f"Macro F1:           {f1_macro:.4f}")
    print(f"Weighted F1:        {f1_weighted:.4f}")

    if accuracy >= 0.85:
        print("\n✓ Required >85% accuracy target achieved.")
    else:
        print(
            "\nWARNING: The held-out test accuracy is below 85%. "
            "Do not report >85% unless the actual evaluation achieves it."
        )

    return metrics


# -------------------------------------------------------------------
# MAIN
# -------------------------------------------------------------------

def main():
    train, test, encoder = load_datasets()

    print("\nTraining samples:", len(train))
    print("Test samples:", len(test))
    print("Classes:", list(encoder.classes_))

    y_train = encoder.transform(
        train["category"].astype(str)
    )

    y_test = encoder.transform(
        test["category"].astype(str)
    )

    X_train, X_test = create_embeddings(
        train,
        test
    )

    model = build_ann(
        input_dim=X_train.shape[1],
        number_of_classes=len(encoder.classes_)
    )

    model.summary()

    # When using an already balanced training file,
    # equal weighting is appropriate.
    unique, counts = np.unique(
        y_train,
        return_counts=True
    )

    is_balanced = (
        len(set(counts.tolist())) == 1
    )

    class_weight = None

    if not is_balanced:
        weights = compute_class_weight(
            class_weight="balanced",
            classes=unique,
            y=y_train
        )

        class_weight = {
            int(cls): float(weight)
            for cls, weight in zip(unique, weights)
        }

        print(
            "\nApplying class weights:",
            class_weight
        )

    callbacks = [
        tf.keras.callbacks.EarlyStopping(
            monitor="val_loss",
            patience=7,
            restore_best_weights=True
        ),

        tf.keras.callbacks.ReduceLROnPlateau(
            monitor="val_loss",
            factor=0.5,
            patience=3,
            min_lr=1e-6
        )
    ]

    history = model.fit(
        X_train,
        y_train,

        validation_split=0.15,

        epochs=60,

        batch_size=32,

        class_weight=class_weight,

        callbacks=callbacks,

        verbose=1
    )

    pd.DataFrame(
        history.history
    ).to_csv(
        MODEL_DIR / "training_history.csv",
        index=False
    )

    model.save(
        MODEL_DIR / "complaint_ann.keras"
    )

    evaluate_model(
        model,
        X_test,
        y_test,
        encoder
    )

    print(
        "\nSaved ANN model to:",
        MODEL_DIR / "complaint_ann.keras"
    )


if __name__ == "__main__":
    main()
