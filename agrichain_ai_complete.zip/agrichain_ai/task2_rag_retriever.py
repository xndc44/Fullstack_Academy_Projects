"""
Reusable semantic retriever for AgriChain Task 2.
"""

from pathlib import Path
import json

import faiss
from sentence_transformers import SentenceTransformer


EMBEDDING_MODEL_NAME = (
    "sentence-transformers/all-MiniLM-L6-v2"
)

BASE_DIR = Path(__file__).resolve().parent

FAISS_DIR = (
    BASE_DIR /
    "artifacts" /
    "faiss"
)

INDEX_FILE = (
    FAISS_DIR /
    "knowledge.index"
)

METADATA_FILE = (
    FAISS_DIR /
    "knowledge_metadata.json"
)


_embedding_model = None
_index = None
_metadata = None


def _load_resources():
    global _embedding_model
    global _index
    global _metadata

    if _embedding_model is None:
        _embedding_model = SentenceTransformer(
            EMBEDDING_MODEL_NAME
        )

    if _index is None:
        _index = faiss.read_index(
            str(INDEX_FILE)
        )

    if _metadata is None:
        with open(
            METADATA_FILE,
            "r",
            encoding="utf-8"
        ) as f:
            _metadata = json.load(f)


def retrieve(query, k=5):
    """
    Retrieve the top-k semantically relevant knowledge records.
    """
    _load_resources()

    query_embedding = (
        _embedding_model.encode(
            [query],
            normalize_embeddings=True,
            convert_to_numpy=True
        )
        .astype("float32")
    )

    scores, ids = _index.search(
        query_embedding,
        k
    )

    results = []

    for rank, (score, idx) in enumerate(
        zip(scores[0], ids[0]),
        start=1
    ):
        if idx < 0:
            continue

        record = dict(
            _metadata[idx]
        )

        record["rank"] = rank
        record["similarity_score"] = float(
            score
        )

        results.append(
            record
        )

    return results


if __name__ == "__main__":
    examples = [
        "My shipment is five days late. What should we do?",
        "The invoice charged more than our agreed contract price.",
        "Several produce boxes arrived crushed and unusable.",
        "What is the escalation policy for a critical complaint?",
        "Tell me about supplier SUP-6421."
    ]

    for query in examples:
        print("\n" + "=" * 80)
        print("QUERY:", query)

        hits = retrieve(
            query,
            k=3
        )

        for hit in hits:
            print(
                f"\n#{hit['rank']} "
                f"{hit['doc_id']} | "
                f"{hit['doc_type']} | "
                f"{hit['category']} | "
                f"score={hit['similarity_score']:.4f}"
            )

            print(
                hit["content"]
            )
