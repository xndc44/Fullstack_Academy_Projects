"""
Task 3 multi-agent test runner.

By default it samples 5 complaints from the supplied held-out test data.
This is intentionally small because each end-to-end test invokes several LLM
calls. Increase --n when you want a larger agent evaluation.

Outputs:
    artifacts/task3/agent_test_results.json
    artifacts/task3/agent_test_summary.json
"""

from pathlib import Path
import argparse
import json

import pandas as pd

from task3_agents import resolve_complaint


BASE_DIR = Path(__file__).resolve().parent

TEST_FILE = (
    BASE_DIR /
    "data" /
    "processed" /
    "complaints_test_processed.csv"
)

OUTPUT_DIR = (
    BASE_DIR /
    "artifacts" /
    "task3"
)


def normalize_priority(value):
    return str(value).strip().lower()


def expected_escalation(priority):
    """
    Ground-truth proxy for testing:
    source priority high/critical should trigger human escalation.
    """
    return (
        normalize_priority(priority)
        in {"high", "critical"}
    )


def run_test(n=5):
    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    df = pd.read_csv(
        TEST_FILE
    )

    n = min(
        n,
        len(df)
    )

    # Fixed random seed gives reproducible samples.
    sample = df.sample(
        n=n,
        random_state=42
    )

    results = []

    for _, row in sample.iterrows():
        print(
            "\nProcessing:",
            row["complaint_id"]
        )

        report = resolve_complaint(
            complaint=row["complaint_text"],
            complaint_id=str(
                row["complaint_id"]
            ),
            customer_id=str(
                row["customer_id"]
            ),
            supplier_id=str(
                row["supplier_id"]
            ),
            order_id=str(
                row["order_id"]
            ),
            region=str(
                row["region"]
            ),
            channel=str(
                row["channel"]
            ),
            provided_priority=str(
                row["priority"]
            )
        )

        predicted_category = (
            report["classification"]["category"]
        )

        actual_category = (
            row["category"]
        )

        actual_should_escalate = (
            expected_escalation(
                row["priority"]
            )
        )

        agent_escalated = bool(
            report["escalation"]["required"]
        )

        result = {
            "complaint_id": (
                row["complaint_id"]
            ),

            "actual_category": (
                actual_category
            ),

            "predicted_category": (
                predicted_category
            ),

            "classifier_correct": (
                predicted_category
                == actual_category
            ),

            "source_priority": (
                row["priority"]
            ),

            "expected_priority_escalation": (
                actual_should_escalate
            ),

            "agent_escalated": (
                agent_escalated
            ),

            "priority_escalation_consistent": (
                (
                    not actual_should_escalate
                )
                or agent_escalated
            ),

            "retrieved_doc_ids": (
                report[
                    "investigation"
                ][
                    "relevant_doc_ids"
                ]
            ),

            "report": report
        }

        results.append(
            result
        )

    classifier_accuracy = (
        sum(
            item["classifier_correct"]
            for item in results
        )
        / len(results)
    )

    required_escalations = [
        item
        for item in results
        if item[
            "expected_priority_escalation"
        ]
    ]

    if required_escalations:
        escalation_recall = (
            sum(
                item["agent_escalated"]
                for item in required_escalations
            )
            / len(
                required_escalations
            )
        )
    else:
        escalation_recall = None

    summary = {
        "samples_tested": len(results),

        "sample_classifier_accuracy": (
            classifier_accuracy
        ),

        "high_or_critical_cases": (
            len(
                required_escalations
            )
        ),

        "high_or_critical_escalation_recall": (
            escalation_recall
        ),

        "reports_with_retrieved_evidence": (
            sum(
                bool(
                    item[
                        "report"
                    ][
                        "investigation"
                    ][
                        "retrieved_evidence"
                    ]
                )
                for item in results
            )
        )
    }

    with open(
        OUTPUT_DIR /
        "agent_test_results.json",
        "w",
        encoding="utf-8"
    ) as f:
        json.dump(
            results,
            f,
            indent=2,
            default=str
        )

    with open(
        OUTPUT_DIR /
        "agent_test_summary.json",
        "w",
        encoding="utf-8"
    ) as f:
        json.dump(
            summary,
            f,
            indent=2
        )

    print(
        "\n" +
        "=" * 70
    )

    print(
        "TASK 3 TEST SUMMARY"
    )

    print(
        "=" * 70
    )

    print(
        json.dumps(
            summary,
            indent=2
        )
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--n",
        type=int,
        default=5,
        help=(
            "Number of held-out complaints "
            "to run through all agents."
        )
    )

    args = parser.parse_args()

    run_test(
        n=args.n
    )
